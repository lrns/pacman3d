java -cp ./bin:res:jar/lwjgl.jar:jar/lwjgl_test.jar:jar/lwjgl_util.jar:jar/lwjgl_fmod3.jar:jar/lwjgl_devil.jar:jar/slick-util.jar:jar/jinput.jar: -Djava.library.path=native/linux Main $1
